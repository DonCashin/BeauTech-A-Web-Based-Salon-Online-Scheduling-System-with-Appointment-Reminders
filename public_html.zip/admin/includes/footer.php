<!--footer-->
    <div class="footer">
       <p> BPMS Admin Panel.</p>
    </div>
        <!--//footer-->