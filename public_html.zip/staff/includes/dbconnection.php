<?php
$con=mysqli_connect("localhost", "u272508820_admin", "AuroraAdmin@123", "u272508820_bpmsdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}
?>
